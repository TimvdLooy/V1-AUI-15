<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voortgangspagina HU</title>

    <link rel="stylesheet" href="CSSWebsite.css">

</head>
<body>

  <ul class="navBar">
    <?php

      $navLinks = array(
      array("Home", "http://localhost/Website/homepagina.php"),
      array("Instellingen", "http://localhost/Website/Instellingenpagina.php"),
      array("Voortgang", "http://localhost/Website/voortgangpagina.php")
      );

      for($i=0; $i<count($navLinks); $i++){
        if($i != 2){
          echo "<li><a href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
        }
        else{
          echo "<li><a class=\"active\" href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
        }
      }

    ?>
  </ul>

  <h1>Voortgang</h1>
  <p class="textIMG">Student:</p>
  <img class= "voortgangIMG" src="http://www.dr-aart.nl/Formules_bestanden/Grafiekenbasis2.jpg" alt="grafiek">
  <form type="">
    <table class="tabel">
      <tr>
        <th>Vakcode</th>
        <th>ECTS</th>
        <th>Datum behaald</th>
      </tr>
      <?php

        $data = array(
          array("TICT-V1PROG-15 ", "5"),
          array("TICT-V1CSN-15 ", "5"),
          array("TICT-V1ICOR-15 ", "5"),
          array("TICT-V1MOD-15 ", "5"),
          array("TICT-V1PROF-15 ", "5"),
          array("TICT-V1IDP-15 ", "5"),
          array("TCIF-V1AUI-15 ", "5"),
          array("TCIT-V1OODC-15 ", "5"),
          array("TCIT-V1GP-15 ", "5")
          );

        $type = array("string","number");
        $id = array("Klas-","Number-");

        $row = 0;
        for($i=0; $i<count($data); $i++){
          echo "<tr>";
          for($j=0; $j<2; $j++){
            echo "<td><input id=" . $id[$j] . $row . " type=" . $type[$j] . " value=". $data[$row][$j] . "></td>";
            if($j == 1){
              echo "<td><input type=\"date\" id=Datum-" . $row . "></td>";
            }
          }
          echo "</tr>";
          $row++;
        }
       ?>
     </table>
   </form>

   <button id="popUpButton" class="Button" onclick="ingedrukt()">Bereken studietempo</button>

   <div id="Scherm" class="Scherm">
     <div class="Scherm-content">
       <div class="Scherm-header">
         <h2>Studietempo</h2>
       </div>
       <p id = "changeMe">je hebt tot nu toe ??? studiepunten gehaald</p>
       <p id = "changeMe2">je huidige studietempo is: <br> ??? ECTS/mnd.</p>
       <p id = "changeMe3">Op basis van dit studietempo heb je ??? mnd nodig voor je P</p>
     </div>

     <div>
       <button id="closeScherm" class="Scherm-knop">OK</button>
     </div>

   </div>

   <?php
   include "bottom.php";
   ?>

   <script src="JsCode.js"></script>
</body>
</html>
