<div class="Bottom">
  <p class="centerText">Deze opdracht is gemaakt in het kader van het vak Analysis & User Interfaces</p><br>
  <p class="Auteur"> Auteur: Tim van de looy</p>
  <p class="Datum">Datum: 14 februari 2017</p>
</div>
