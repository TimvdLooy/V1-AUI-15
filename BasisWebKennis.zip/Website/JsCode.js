var Scherm = document.getElementById('Scherm');

var btn = document.getElementById("popUpButton");

var closebtn = document.getElementById("closeScherm")

btn.onclick = function() {
    Scherm.style.display = "block";
    var datum = [document.getElementById('Datum-0').value, document.getElementById('Datum-1').value, document.getElementById('Datum-2').value, document.getElementById('Datum-3').value, document.getElementById('Datum-4').value, document.getElementById('Datum-5').value,
    document.getElementById('Datum-6').value, document.getElementById('Datum-7').value, document.getElementById('Datum-8').value];
    var punten = [document.getElementById('Number-0').value, document.getElementById('Number-1').value, document.getElementById('Number-2').value, document.getElementById('Number-3').value, document.getElementById('Number-4').value,
    document.getElementById('Number-5').value,document.getElementById('Number-6').value, document.getElementById('Number-7').value, document.getElementById('Number-8').value]
    var studiepunten = 0;
    for(i = 0; i<datum.length; i++){
      if(datum[i] != ""){
        studiepunten = studiepunten + Number(punten[i]);
      }
    }
    var huidigeDatum = new Date();
    var Month = huidigeDatum.getMonth()+1;
    var PointsPerMonth = studiepunten * 5 / Month;
    document.getElementById("changeMe2").innerHTML = "je huidige studietempo is: <br>" + PointsPerMonth + " ECTS/mnd."
    document.getElementById("changeMe").innerHTML = "je hebt tot nu toe " + studiepunten + " studiepunten gehaald" ;
    document.getElementById("changeMe3").innerHTML = "Op basis van dit studietempo heb je " + 45/PointsPerMonth + " mnd nodig voor je P"
}

closebtn.onclick = function() {
    Scherm.style.display = "none";
}
