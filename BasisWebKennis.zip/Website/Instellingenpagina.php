<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Instellingen HU</title>

    <link rel="stylesheet" href="CSSWebsite.css">
    <script src="JavaScript.js"></script>

</head>
<body>

  <ul class="navBar">
    <?php

      $navLinks = array(
      array("Home", "http://localhost/Website/homepagina.php"),
      array("Instellingen", "http://localhost/Website/Instellingenpagina.php"),
      array("Voortgang", "http://localhost/Website/voortgangpagina.php")
      );

      for($i=0; $i<count($navLinks); $i++){
        if($i != 1){
          echo "<li><a href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
        }
        else{
          echo "<li><a class=\"active\" href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
        }
      }

    ?>
  </ul>

	<h1>Instellingen</h1>

  <form action="">
  	<?php

  		$inputB = array("Voornaam: ", "Achternaam: ", "Studentennr: ", "E-mail: ");
  		$inputN = array("Voornaam", "Achternaam", "Studentennr", "E-mail");
      $type = array("text", "text", "number", "email");

      echo "<ul class=\"input\">";
  		for($i=0; $i<count($inputB); $i++){
  			echo "<li><label>" . $inputB[$i] . "</label></li><input class=\"inputList\" type=" . $type[$i] . " name=" . $inputN[$i] . " required>";
  			if($i == 3){
  				echo "<li><label> Geboortedatum: </label></li><input class=\"inputList\" type = \"date\" name=\"Geboortedatum\" required>";
  			}
  		}
      echo "</ul>";

  		$alphabet = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U");
  		$Value = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U");

      echo "<ul class=\"inputr\">";
  	  echo "<li><label>Klas: <select>";
  		for($i=0; $i<count($alphabet); $i++){
  				  echo "<option value=" . $Value[$i] . ">V1" . $alphabet[$i] . "</option>";
  		}
      echo "</select></label></li>";

      $studierichtingen = array("SNE", "BIM", "SIE", "TI");

      echo "<li><label> Gekozen Studierichting: </label><ul>";
      for($i=0; $i<count($studierichtingen); $i++){
        echo  "<li><input required type=\"radio\" name=\"richting\" value=" . $studierichtingen[$i] . ">" . $studierichtingen[$i]. "</li>";
      }
      echo "</ul></li>";

      $antwoord = array("Ja", "Nee");
      echo "<li><label>Propedeuse behaald: </label><ul>";
      for($i=0; $i<count($antwoord); $i++){
        echo  "<li><input required type=\"radio\" name=\"antwoord\" value=" . $antwoord[$i] . ">" . $antwoord[$i] . "</li>";
      }
      echo "</ul>";
      echo "</li>";
      echo "</ul>";



  	?>
  </form>

  <?php
  include "bottom.php";
  ?>

</body>
</html>
