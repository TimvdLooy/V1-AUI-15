<ul class="navBar">
  <?php

    $navLinks = array(
    array("Home", "http://localhost/Website/homepagina.php"),
    array("Instellingen", "http://localhost/Website/Instellingenpagina.php"),
    array("Voortgang", "http://localhost/Website/voortgangpagina.php")
    );

    for($i=0; $i<count($navLinks); $i++){
      echo "<li><a href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
    }

  ?>
</ul>
