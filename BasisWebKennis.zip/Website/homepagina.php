<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Homepagina HU</title>

    <script src="js.js"></script>
    <link rel="stylesheet" href="CSSWebsite.css">

</head>
<body>

  <ul class="navBar">
    <?php

      $navLinks = array(
      array("Home", "http://localhost/Website/homepagina.php"),
      array("Instellingen", "http://localhost/Website/Instellingenpagina.php"),
      array("Voortgang", "http://localhost/Website/voortgangpagina.php")
      );

      echo "<li><a class=\"active\" href=" . $navLinks[0][1] . ">" . $navLinks[0][0] . "</a></li>";

      for($i=1; $i<count($navLinks); $i++){
        echo "<li><a href=" . $navLinks[$i][1] . ">" . $navLinks[$i][0] . "</a></li>";
      }

    ?>
  </ul>

  <h1>Voortgangsmonitor</h1>

  <img src="https://www.hu.nl/includes/img/HU-Platform/hu-og.png" alt="HU" class="imgRigth">
  <div class="samenvatting">
    <p> Deze persoonlijke voortgangsmonitor dient je inzicht te geven in je studievoortgang. Op de <a href="http://localhost/Website/Instellingenpagina.php">Instellingen</a> pagina kun je informatie omtrent je persoon instellen. Op de <a href="/Website/voortgangpagina.php">voortgang </a> pagina kun je vervolgende je vakken invullen, het aantal ECTS ervan en de datum waarop je het vak hebt behaald. Door op de knop bereken studietempo te klikken zal vervolgens een dialogvenster verschijnen dat op basis van de ingevoerde inforamatie je studietempo berekend.</p>
  </div>

  <p class="Disclaimer"> Deze versie van de voortgangsmonitor is echter nog beperkt in zijn functionaliteit, omdat het niet zo zeer om de werking ervan gaat, maar veelmeer om goede omzetting van een wireframe naar een HTML,CSS en JS.</p>
  <img src="https://www.hu.nl/~/media/LLL/Images/Detail/Gebouwen/Padualaan%2099/Int/HU_FCJ_004.jpg" alt="Leerplek met studenten" class="imgCenter">

  <?php
  include "bottom.php";
  ?>

</body>
</html>
